test = {   'name': 'q3a',
    'points': 1,
    'suites': [   {   'cases': [   {   'code': '>>> valid_values\n'
                                               'array([0.95071431, 0.86617615, 0.96990985, 0.94888554, 0.96563203,\n'
                                               '       0.9093204 , 0.96958463, 0.93949894, 0.89482735, 0.92187424])',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
