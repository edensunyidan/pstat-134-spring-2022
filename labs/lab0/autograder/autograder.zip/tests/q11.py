test = {   'name': 'q11',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> 'a' in y11\nTrue", 'hidden': False, 'locked': False}, {'code': ">>> 'b' in y11\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
