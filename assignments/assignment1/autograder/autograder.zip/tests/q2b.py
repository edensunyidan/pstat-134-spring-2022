test = {   'name': 'q2b',
    'points': 3,
    'suites': [   {   'cases': [   {'code': '>>> \n>>> assert isinstance(rising_candidate, str) and isinstance(falling_candidate, str) \n', 'hidden': False, 'locked': False},
                                   {'code': ">>> \n>>> rising_candidate\n'Sharice Davids'", 'hidden': True, 'locked': False},
                                   {'code': ">>> \n>>> falling_candidate\n'Kevin Yoder'", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
