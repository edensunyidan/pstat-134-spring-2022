test = {   'name': 'q2',
    'points': 1,
    'suites': [   {   'cases': [{'code': '>>> arr\narray([1, 2, 3, 4, 5])', 'hidden': False, 'locked': False}, {'code': '>>> type(arr) is np.ndarray\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
