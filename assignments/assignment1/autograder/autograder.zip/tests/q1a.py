test = {   'name': 'q1a',
    'points': 5,
    'suites': [   {   'cases': [   {'code': '>>> \n>>> all(election_sub[\'forecast_type\'] == "classic")\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> \n>>> all((x == "2018-08-11") | (x == "2018-11-06") for x in election_sub[\'forecast_date\'])\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
