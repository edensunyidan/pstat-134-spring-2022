test = {   'name': 'q12',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> 'a' in y12\nTrue", 'hidden': False, 'locked': False}, {'code': ">>> 'b' in y12\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
