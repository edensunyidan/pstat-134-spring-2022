test = {   'name': 'q21',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> 'a' in y21\nTrue", 'hidden': True, 'locked': False}, {'code': ">>> 'b' in y21\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
