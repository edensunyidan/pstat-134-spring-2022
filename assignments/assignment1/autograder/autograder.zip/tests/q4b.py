test = {   'name': 'q4b',
    'points': 5,
    'suites': [   {   'cases': [   {'code': '>>> \n>>> all(np.array(midpoints) >= 0) & all(np.array(midpoints) <= 1)\nTrue', 'hidden': False, 'locked': False},
                                   {   'code': '>>> \n'
                                               '>>> np.round(midpoints, 4)\n'
                                               'array([0.0263, 0.0789, 0.1316, 0.1842, 0.2368, 0.2895, 0.3421, 0.3947,\n'
                                               '       0.4474, 0.5   , 0.5526, 0.6053, 0.6579, 0.7105, 0.7632, 0.8158,\n'
                                               '       0.8684, 0.9211, 0.9737])',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
