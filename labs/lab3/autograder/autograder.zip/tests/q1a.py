test = {   'name': 'q1a',
    'points': 3,
    'suites': [   {   'cases': [{'code': '>>> calls_by_cvlegend_and_offense["LARCENY", "THEFT FROM PERSON"] == 24\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
