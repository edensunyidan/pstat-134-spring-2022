test = {   'name': 'q22',
    'points': 3,
    'suites': [   {   'cases': [{'code': ">>> 'a' in y22\nTrue", 'hidden': True, 'locked': False}, {'code': ">>> 'b' in y22\nTrue", 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
